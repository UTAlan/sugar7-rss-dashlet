'RSS Feed Dashlet'.

The end user may bring the dashlet to his home page and get the 5 latest items from a specified RSS URL.

Available in English.

Copyright 2015 Alan Beam - All rights reserved.

Release notes:
v 1.0.1 - 28 January 2015
Fixed issue of feeds with fewer than 5 items not displaying.

v 1.0.0 - 19 January 2015
Original release.
