'Football Worldcup 2014 Dashlet'.

This dashlet consumes data from the API 'World Cup in JSON'.
http://worldcup.sfg.io/

The end user may bring the dashlet to his home page and get:
- the games scheduled today
- his favourite team games and results

available in:
English, French, Dutch, Swedish and Russian.

Copyright 2014 Olivier Nepomiachty - All rights reserved.

Release notes:
v 1.0.1.0 - 29 June 2014
Replace the PHP script that calls to external API by a Sugar 7 endpoint.

v 1.0.0.24 - 27 June 2014
Original release.
